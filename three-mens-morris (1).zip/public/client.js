const socket = io();
const boardEl = document.getElementById('board');
const statusEl = document.getElementById('status');
let playerSymbol = '';
let currentTurn = '';
let gameState = Array(9).fill(null);
let placedPieces = 0;
let totalPlaced = 0;

function createBoard() {
    boardEl.innerHTML = '';
    for (let i = 0; i < 9; i++) {
        const cell = document.createElement('div');
        cell.classList.add('cell');
        cell.dataset.index = i;
        cell.addEventListener('click', () => handleCellClick(i));
        boardEl.appendChild(cell);
    }
}

function handleCellClick(index) {
    if (gameState[index] || currentTurn !== playerSymbol || placedPieces >= 3 && !canMove(index)) return;

    socket.emit('move', { index, symbol: playerSymbol });
}

function canMove(index) {
    return gameState[index] === playerSymbol;
}

socket.on('assignSymbol', symbol => {
    playerSymbol = symbol;
    statusEl.textContent = `You are ${playerSymbol}`;
});

socket.on('updateGame', ({ board, turn }) => {
    gameState = board;
    currentTurn = turn;
    placedPieces = board.filter(s => s === playerSymbol).length;
    totalPlaced = board.filter(s => s !== null).length;

    const cells = document.querySelectorAll('.cell');
    cells.forEach((cell, i) => {
        cell.textContent = board[i] || '';
    });

    statusEl.textContent = currentTurn === playerSymbol ? "Your turn" : "Opponent's turn";
});

createBoard();