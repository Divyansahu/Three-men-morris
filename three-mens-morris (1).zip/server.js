const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static('public'));

let players = [];
let board = Array(9).fill(null);
let turn = 'X';

io.on('connection', socket => {
    if (players.length >= 2) {
        socket.disconnect();
        return;
    }

    const symbol = players.length === 0 ? 'X' : 'O';
    players.push({ id: socket.id, symbol });
    socket.emit('assignSymbol', symbol);
    io.emit('updateGame', { board, turn });

    socket.on('move', ({ index, symbol }) => {
        if (symbol !== turn || board[index]) return;
        board[index] = symbol;
        turn = turn === 'X' ? 'O' : 'X';
        io.emit('updateGame', { board, turn });
    });

    socket.on('disconnect', () => {
        players = players.filter(p => p.id !== socket.id);
        board = Array(9).fill(null);
        turn = 'X';
        io.emit('updateGame', { board, turn });
    });
});

server.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});